import { ParseuaPipe } from './parseua.pipe';

describe('ParseuaPipe', () => {
  it('create an instance', () => {
    const pipe = new ParseuaPipe();
    expect(pipe).toBeTruthy();
  });
});
