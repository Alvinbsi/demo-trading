import { Obj.NgFor.PipePipe } from './obj.ng-for.pipe.pipe';

describe('Obj.NgFor.PipePipe', () => {
  it('create an instance', () => {
    const pipe = new Obj.NgFor.PipePipe();
    expect(pipe).toBeTruthy();
  });
});
