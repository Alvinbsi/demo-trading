export class HybseConfig {
 //apiURL:string = 'https://api.hybse.dev/';
 //apiURL:string = 'http://127.0.0.1:8000/';
 //apiURL:string = 'https://apollo.hybsedev.ddns.net/';
 apiURL:string = 'https://apollo.business-software.in/';
}
