import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
