import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-edit-market',
  templateUrl: './edit-market.component.html',
  styleUrls: ['./edit-market.component.css']
})
export class EditMarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
