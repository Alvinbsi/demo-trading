import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-update-page',
  templateUrl: './update-page.component.html',
  styleUrls: ['./update-page.component.css']
})
export class UpdatePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
