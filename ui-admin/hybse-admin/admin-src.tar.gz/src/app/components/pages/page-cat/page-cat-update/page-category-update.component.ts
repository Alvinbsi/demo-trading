import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-page-category-update',
  templateUrl: './page-category-update.component.html',
  styleUrls: ['./page-category-update.component.css']
})
export class PageCategoryUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
