import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-latesttickets',
  templateUrl: './latesttickets.component.html',
  styleUrls: ['./latesttickets.component.css']
})
export class LatestticketsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
