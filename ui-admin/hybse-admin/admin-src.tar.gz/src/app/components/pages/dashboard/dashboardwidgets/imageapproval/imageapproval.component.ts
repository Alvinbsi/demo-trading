import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-imageapproval',
  templateUrl: './imageapproval.component.html',
  styleUrls: ['./imageapproval.component.css']
})
export class ImageapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
