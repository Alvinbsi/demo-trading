import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-recentactivities',
  templateUrl: './recentactivities.component.html',
  styleUrls: ['./recentactivities.component.css']
})
export class RecentactivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
