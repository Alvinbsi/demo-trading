import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-documentapproval',
  templateUrl: './documentapproval.component.html',
  styleUrls: ['./documentapproval.component.css']
})
export class DocumentapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
