import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-investoradduser',
  templateUrl: './investor-add-user.component.html',
  styleUrls: ['./investor-add-user.component.css']
})
export class InvestorAddUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
