import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
