import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hybse-admin-translation',
  templateUrl: './translation.component.html',
  styleUrls: ['./translation.component.css']
})
export class TranslationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
