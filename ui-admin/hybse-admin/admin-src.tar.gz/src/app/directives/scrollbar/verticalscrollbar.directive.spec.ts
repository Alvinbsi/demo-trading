import { VerticalscrollbarDirective } from './verticalscrollbar.directive';

describe('VerticalscrollbarDirective', () => {
  it('should create an instance', () => {
    const directive = new VerticalscrollbarDirective();
    expect(directive).toBeTruthy();
  });
});
