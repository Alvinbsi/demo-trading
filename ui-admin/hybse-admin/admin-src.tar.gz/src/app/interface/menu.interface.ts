export interface Menu {
  title: string,
  path: string,
  icon: string,
  subMenuCollapse: boolean,
  submenu: any
}
